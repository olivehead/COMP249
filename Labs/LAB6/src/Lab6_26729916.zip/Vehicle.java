import java.io.Serializable;

public class Vehicle implements Serializable {
	String brand;

	public Vehicle() {
	}

	public String getBrand() {
		return brand;
	}
}
